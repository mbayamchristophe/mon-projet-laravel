<?php

namespace Database\Seeders;

use App\Models\Client;
use App\Models\Produit;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Clients - Utilisation de updateOrCreate pour éviter les erreurs de duplication
        Client::updateOrCreate(
            ['email' => 'ali@example.com'],
            [
                'nom' => 'Ali',
                'prenom' => 'Monsieur',
                'telephone' => '0123456789',
                'adresse' => '123 Rue de la Paix'
            ]
        );

        Client::updateOrCreate(
            ['email' => 'jean@example.com'],
            [
                'nom' => 'Dupont',
                'prenom' => 'Jean',
                'telephone' => '0987654321',
                'adresse' => '456 Avenue des Champs'
            ]
        );

        // Produits
        Produit::updateOrCreate(
            ['reference' => 'PROD-001'],
            [
                'designation' => 'Ordinateur Portable',
                'prix_unitaire' => 850.00,
                'quantite_stock' => 15,
                'description' => 'Un ordinateur puissant pour le travail.'
            ]
        );

        Produit::updateOrCreate(
            ['reference' => 'PROD-002'],
            [
                'designation' => 'Souris Sans Fil',
                'prix_unitaire' => 25.00,
                'quantite_stock' => 50,
                'description' => 'Souris ergonomique.'
            ]
        );

        Produit::updateOrCreate(
            ['reference' => 'PROD-003'],
            [
                'designation' => 'Écran 24 pouces',
                'prix_unitaire' => 150.00,
                'quantite_stock' => 10,
                'description' => 'Écran Full HD.'
            ]
        );
    }
}
