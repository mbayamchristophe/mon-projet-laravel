@extends('layouts.app')

@section('title', 'Ajouter un Produit')

@section('content')
<div class="max-w-2xl mx-auto bg-white shadow-md rounded-lg overflow-hidden">
    <div class="px-6 py-4 border-b">
        <h2 class="text-xl font-semibold text-gray-800">Nouveau Produit</h2>
    </div>
    <form action="{{ route('produits.store') }}" method="POST" class="p-6">
        @csrf
        <div class="grid grid-cols-1 gap-6">
            <div>
                <label class="block text-sm font-medium text-gray-700">Référence</label>
                <input type="text" name="reference" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Désignation</label>
                <input type="text" name="designation" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Prix Unitaire</label>
                    <input type="number" step="0.01" name="prix_unitaire" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Quantité en Stock</label>
                    <input type="number" name="quantite_stock" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Description</label>
                <textarea name="description" rows="3" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2"></textarea>
            </div>
        </div>
        <div class="mt-6 flex items-center justify-end">
            <a href="{{ route('produits.index') }}" class="text-gray-600 hover:text-gray-900 mr-4">Annuler</a>
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Enregistrer</button>
        </div>
    </form>
</div>
@endsection
