<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') - Boutique Ali</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @media print {
            .no-print { display: none !important; }
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
    <!-- Barre de navigation -->
    <nav class="bg-blue-800 text-white shadow-lg no-print">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
            <a href="{{ url('/') }}" class="text-2xl font-bold tracking-wider">BOUTIQUE ALI</a>
            <div class="space-x-6">
                <a href="{{ url('/') }}" class="hover:text-blue-200 transition">Accueil</a>
                <a href="{{ route('clients.index') }}" class="hover:text-blue-200 transition">Clients</a>
                <a href="{{ route('produits.index') }}" class="hover:text-blue-200 transition">Produits</a>
                <a href="{{ route('commandes.index') }}" class="hover:text-blue-200 transition">Commandes</a>
            </div>
        </div>
    </nav>

    <!-- Contenu principal -->
    <main class="container mx-auto px-6 py-8">
        @if(session('success'))
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 shadow-sm" role="alert">
                {{ session('success') }}
            </div>
        @endif

        @if($errors->any())
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 shadow-sm">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @yield('content')
    </main>

    <!-- Pied de page -->
    <footer class="bg-white border-t mt-12 py-6 no-print">
        <div class="container mx-auto px-6 text-center text-gray-500">
            &copy; 2026 Boutique de Monsieur Ali - Projet GI2
        </div>
    </footer>
</body>
</html>
