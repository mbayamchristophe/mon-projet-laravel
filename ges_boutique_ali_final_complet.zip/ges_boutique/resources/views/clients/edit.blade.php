@extends('layouts.app')

@section('title', 'Modifier le Client')

@section('content')
<div class="max-w-2xl mx-auto bg-white shadow-md rounded-lg overflow-hidden">
    <div class="px-6 py-4 border-b">
        <h2 class="text-xl font-semibold text-gray-800">Modifier le Client</h2>
    </div>
    <form action="{{ route('clients.update', $client) }}" method="POST" class="p-6">
        @csrf
        @method('PUT')
        <div class="grid grid-cols-1 gap-6">
            <div>
                <label class="block text-sm font-medium text-gray-700">Nom</label>
                <input type="text" name="nom" value="{{ $client->nom }}" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Prénom</label>
                <input type="text" name="prenom" value="{{ $client->prenom }}" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Email</label>
                <input type="email" name="email" value="{{ $client->email }}" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Téléphone</label>
                <input type="text" name="telephone" value="{{ $client->telephone }}" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Adresse</label>
                <textarea name="adresse" rows="3" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>{{ $client->adresse }}</textarea>
            </div>
        </div>
        <div class="mt-6 flex items-center justify-end">
            <a href="{{ route('clients.index') }}" class="text-gray-600 hover:text-gray-900 mr-4">Annuler</a>
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Mettre à jour</button>
        </div>
    </form>
</div>
@endsection
