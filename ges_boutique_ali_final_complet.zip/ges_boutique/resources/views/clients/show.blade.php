@extends('layouts.app')

@section('title', 'Détails du Client')

@section('content')
<div class="max-w-2xl mx-auto bg-white shadow-md rounded-lg overflow-hidden">
    <div class="px-6 py-4 border-b flex justify-between items-center">
        <h2 class="text-xl font-semibold text-gray-800">Détails du Client</h2>
        <a href="{{ route('clients.index') }}" class="text-blue-600 hover:underline">Retour à la liste</a>
    </div>
    <div class="p-6">
        <div class="grid grid-cols-1 gap-4">
            <div>
                <span class="block text-sm font-medium text-gray-500">Nom complet</span>
                <p class="text-lg text-gray-900">{{ $client->nom }} {{ $client->prenom }}</p>
            </div>
            <div>
                <span class="block text-sm font-medium text-gray-500">Email</span>
                <p class="text-lg text-gray-900">{{ $client->email }}</p>
            </div>
            <div>
                <span class="block text-sm font-medium text-gray-500">Téléphone</span>
                <p class="text-lg text-gray-900">{{ $client->telephone }}</p>
            </div>
            <div>
                <span class="block text-sm font-medium text-gray-500">Adresse</span>
                <p class="text-lg text-gray-900">{{ $client->adresse }}</p>
            </div>
        </div>
        <div class="mt-8 flex gap-4">
            <a href="{{ route('clients.edit', $client) }}" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded">
                Modifier les informations
            </a>
            <form action="{{ route('clients.destroy', $client) }}" method="POST" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce client ?');">
                @csrf
                @method('DELETE')
                <button type="submit" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                    Supprimer le client
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
