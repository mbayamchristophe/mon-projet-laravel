@extends('layouts.app')

@section('title', 'Bienvenue - Boutique de Monsieur Ali')

@section('content')
<div class="bg-white shadow-xl rounded-lg overflow-hidden">
    <div class="bg-blue-600 px-6 py-12 text-center text-white">
        <h1 class="text-4xl font-extrabold mb-4">Bienvenue dans la Boutique de Monsieur Ali</h1>
        <p class="text-xl opacity-90">Système de Gestion Commerciale - Projet GI2 2025-2026</p>
    </div>
    
    <div class="p-8 grid grid-cols-1 md:grid-cols-3 gap-8">
        <!-- Carte Clients -->
        <div class="border rounded-lg p-6 hover:shadow-lg transition-shadow bg-blue-50">
            <div class="text-blue-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
            </div>
            <h2 class="text-xl font-bold mb-2">Gestion Clients</h2>
            <p class="text-gray-600 mb-4">Gérez votre base de données clients, ajoutez de nouveaux contacts et consultez leurs informations.</p>
            <a href="{{ route('clients.index') }}" class="inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Accéder aux Clients</a>
        </div>

        <!-- Carte Produits -->
        <div class="border rounded-lg p-6 hover:shadow-lg transition-shadow bg-green-50">
            <div class="text-green-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                </svg>
            </div>
            <h2 class="text-xl font-bold mb-2">Gestion Produits</h2>
            <p class="text-gray-600 mb-4">Consultez votre catalogue, gérez les stocks et mettez à jour les prix de vos articles.</p>
            <a href="{{ route('produits.index') }}" class="inline-block bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Accéder au Stock</a>
        </div>

        <!-- Carte Commandes -->
        <div class="border rounded-lg p-6 hover:shadow-lg transition-shadow bg-purple-50">
            <div class="text-purple-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                </svg>
            </div>
            <h2 class="text-xl font-bold mb-2">Commandes & Factures</h2>
            <p class="text-gray-600 mb-4">Enregistrez de nouvelles ventes et générez instantanément des factures pour vos clients.</p>
            <a href="{{ route('commandes.index') }}" class="inline-block bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">Voir les Commandes</a>
        </div>
    </div>
    
    <div class="bg-gray-50 px-8 py-6 border-t text-center text-gray-500 text-sm">
        Développé pour le cours de Génie Informatique - Session 2025-2026
    </div>
</div>
@endsection
