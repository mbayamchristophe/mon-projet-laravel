@extends('layouts.app')

@section('title', 'Détails Commande ' . $commande->numero_commande)

@section('content')
<div class="max-w-4xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden p-8 border" id="facture">
    <div class="flex justify-between items-start mb-8">
        <div>
            <h1 class="text-3xl font-bold text-blue-600">FACTURE</h1>
            <p class="text-gray-500">N° {{ $commande->numero_commande }}</p>
            <p class="text-gray-500">Date: {{ $commande->date_commande }}</p>
        </div>
        <div class="text-right">
            <h2 class="text-xl font-bold">Ma Boutique</h2>
            <p>123 Rue du Commerce</p>
            <p>75000 Paris</p>
            <p>contact@maboutique.com</p>
        </div>
    </div>

    <div class="mb-8 border-t border-b py-4">
        <h3 class="text-lg font-bold mb-2">Facturé à :</h3>
        <p class="font-semibold">{{ $commande->client->nom }} {{ $commande->client->prenom }}</p>
        <p>{{ $commande->client->adresse }}</p>
        <p>Tél: {{ $commande->client->telephone }}</p>
        <p>Email: {{ $commande->client->email }}</p>
    </div>

    <table class="min-w-full mb-8">
        <thead>
            <tr class="bg-gray-100">
                <th class="px-4 py-2 text-left">Désignation</th>
                <th class="px-4 py-2 text-center">Quantité</th>
                <th class="px-4 py-2 text-right">Prix Unitaire</th>
                <th class="px-4 py-2 text-right">Montant</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            @foreach($commande->produits as $produit)
            <tr>
                <td class="px-4 py-3">{{ $produit->designation }}</td>
                <td class="px-4 py-3 text-center">{{ $produit->pivot->quantite }}</td>
                <td class="px-4 py-3 text-right">{{ number_format($produit->pivot->prix_unitaire, 2) }} €</td>
                <td class="px-4 py-3 text-right">{{ number_format($produit->pivot->quantite * $produit->pivot->prix_unitaire, 2) }} €</td>
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr class="border-t-2">
                <td colspan="3" class="px-4 py-4 text-right font-bold text-xl">TOTAL À PAYER</td>
                <td class="px-4 py-4 text-right font-bold text-xl text-blue-600">{{ number_format($commande->montant_total, 2) }} €</td>
            </tr>
        </tfoot>
    </table>

    <div class="mt-12 text-center text-gray-500 text-sm no-print">
        <button onclick="window.print()" class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded shadow-md">
            Imprimer la Facture (PDF)
        </button>
        <a href="{{ route('commandes.index') }}" class="ml-4 text-blue-600 hover:underline">Retour à l'historique</a>
    </div>
</div>

<style>
    @media print {
        .no-print, nav, footer {
            display: none !important;
        }
        body {
            background-color: white;
        }
        #facture {
            box-shadow: none;
            border: none;
            margin: 0;
            width: 100%;
        }
    }
</style>
@endsection
