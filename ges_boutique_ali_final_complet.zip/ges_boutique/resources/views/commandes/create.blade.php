@extends('layouts.app')

@section('title', 'Nouvelle Commande')

@section('content')
<div class="max-w-4xl mx-auto bg-white shadow-md rounded-lg overflow-hidden">
    <div class="px-6 py-4 border-b">
        <h2 class="text-xl font-semibold text-gray-800">Créer une Commande</h2>
    </div>
    <form action="{{ route('commandes.store') }}" method="POST" class="p-6">
        @csrf
        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700">Client</label>
            <select name="client_id" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
                <option value="">Sélectionnez un client</option>
                @foreach($clients as $client)
                    <option value="{{ $client->id }}">{{ $client->nom }} {{ $client->prenom }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-6">
            <h3 class="text-lg font-medium text-gray-700 mb-4">Produits</h3>
            <div id="produits-container">
                <div class="produit-row flex gap-4 mb-4 items-end">
                    <div class="flex-1">
                        <label class="block text-xs text-gray-500">Produit</label>
                        <select name="produits[0][id]" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
                            <option value="">Choisir un produit</option>
                            @foreach($produits as $produit)
                                <option value="{{ $produit->id }}">{{ $produit->designation }} (Stock: {{ $produit->quantite_stock }}, Prix: {{ $produit->prix_unitaire }} €)</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="w-32">
                        <label class="block text-xs text-gray-500">Quantité</label>
                        <input type="number" name="produits[0][quantite]" min="1" value="1" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 border p-2" required>
                    </div>
                    <button type="button" class="bg-red-500 text-white p-2 rounded remove-row">X</button>
                </div>
            </div>
            <button type="button" id="add-produit" class="mt-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded">
                + Ajouter un produit
            </button>
        </div>

        <div class="mt-8 flex items-center justify-end">
            <a href="{{ route('commandes.index') }}" class="text-gray-600 hover:text-gray-900 mr-4">Annuler</a>
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Valider la Commande</button>
        </div>
    </form>
</div>

<script>
    let rowCount = 1;
    document.getElementById('add-produit').addEventListener('click', function() {
        const container = document.getElementById('produits-container');
        const newRow = container.children[0].cloneNode(true);
        
        newRow.querySelector('select').name = `produits[${rowCount}][id]`;
        newRow.querySelector('input').name = `produits[${rowCount}][quantite]`;
        newRow.querySelector('input').value = 1;
        
        container.appendChild(newRow);
        rowCount++;
    });

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-row')) {
            const rows = document.querySelectorAll('.produit-row');
            if (rows.length > 1) {
                e.target.closest('.produit-row').remove();
            }
        }
    });
</script>
@endsection
