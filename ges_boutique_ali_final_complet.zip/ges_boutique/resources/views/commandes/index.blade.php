@extends('layouts.app')

@section('title', 'Historique des Commandes')

@section('content')
<div class="bg-white shadow overflow-hidden sm:rounded-lg">
    <div class="px-4 py-5 sm:px-6 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-gray-900">Commandes</h1>
        <a href="{{ route('commandes.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Nouvelle Commande
        </a>
    </div>
    <div class="border-t border-gray-200">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">N° Commande</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                @foreach($commandes as $commande)
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">{{ $commande->numero_commande }}</td>
                    <td class="px-6 py-4 whitespace-nowrap">{{ $commande->date_commande }}</td>
                    <td class="px-6 py-4 whitespace-nowrap">{{ $commande->client->nom }} {{ $commande->client->prenom }}</td>
                    <td class="px-6 py-4 whitespace-nowrap font-bold">{{ number_format($commande->montant_total, 2) }} €</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="{{ route('commandes.show', $commande) }}" class="text-blue-600 hover:text-blue-900 mr-3">Détails / Facture</a>
                        <form action="{{ route('commandes.destroy', $commande) }}" method="POST" class="inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('Supprimer cette commande et restaurer le stock ?')">Supprimer</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
