# Guide d'Installation Détaillé — Projet Gestion de Boutique (Laravel)

Ce document vous accompagne pas à pas pour installer et faire fonctionner le projet sur votre machine locale (Windows avec XAMPP ou Linux avec Apache/PHP).

## Étape 1 : Préparation des fichiers
1.  Téléchargez l'archive **ges_boutique_complet.zip**.
2.  Décompressez le dossier `ges_boutique` dans le répertoire de votre serveur web :
    -   **Sur Windows (XAMPP) :** `C:\xampp\htdocs\ges_boutique`
    -   **Sur Linux (Apache) :** `/var/www/html/ges_boutique`

## Étape 2 : Installation des dépendances
Ouvrez un terminal (ou l'invité de commande) à l'intérieur du dossier `ges_boutique` et tapez la commande suivante pour installer les bibliothèques nécessaires :
```bash
composer install
```
*Note : Si vous n'avez pas Composer, téléchargez-le sur [getcomposer.org](https://getcomposer.org/).*

## Étape 3 : Configuration de l'environnement
1.  Dans le dossier `ges_boutique`, cherchez le fichier nommé `.env`.
2.  Si vous utilisez **MySQL** (recommandé pour XAMPP), modifiez les lignes suivantes :
    ```env
    DB_CONNECTION=mysql
    DB_HOST=127.0.0.1
    DB_PORT=3306
    DB_DATABASE=nom_de_votre_base
    DB_USERNAME=root
    DB_PASSWORD=
    ```
3.  Si vous préférez rester sur **SQLite** (déjà configuré dans l'archive), laissez tel quel.

## Étape 4 : Initialisation de l'application
Toujours dans le terminal, exécutez ces trois commandes l'une après l'autre :
1.  **Générer la clé de sécurité :**
    ```bash
    php artisan key:generate
    ```
2.  **Créer les tables de la base de données :**
    ```bash
    php artisan migrate
    ```
3.  **Charger les données de test (Clients et Produits par défaut) :**
    ```bash
    php artisan db:seed
    ```

## Étape 5 : Lancement et test
Vous avez deux façons de voir le site :
1.  **Via Laravel (le plus simple) :**
    Tapez `php artisan serve` dans le terminal, puis ouvrez votre navigateur à l'adresse `http://127.0.0.1:8000`.
2.  **Via Apache (XAMPP) :**
    Assurez-vous qu'Apache est démarré et allez sur `http://localhost/ges_boutique/public`.

## Comment importer la base de données ?
Si vous voulez utiliser **phpMyAdmin** :
1.  Créez une nouvelle base de données vide (ex: `boutique_db`).
2.  Cliquez sur l'onglet **Importer**.
3.  Choisissez le fichier `database/export_base_boutique.sql` qui se trouve dans le dossier du projet.
4.  Cliquez sur **Exécuter**.

## Résumé des fonctionnalités
| Fonctionnalité | Description |
| :--- | :--- |
| **Gestion Clients** | Ajouter, modifier, voir ou supprimer des clients. |
| **Gestion Produits** | Gérer le catalogue et le stock en temps réel. |
| **Commandes** | Créer une commande en sélectionnant plusieurs produits. |
| **Facturation** | Calcul automatique du total et bouton d'impression PDF. |

En cas d'erreur de version PHP, assurez-vous d'utiliser **PHP 8.2 ou supérieur**.
