# Projet Laravel - Gestion de Boutique

Ce projet a été réalisé selon le cahier des charges "ProjetGI22026".

## Prérequis
- PHP >= 8.2
- Composer
- Serveur MySQL ou SQLite
- Apache / Nginx

## Installation Rapide
1. Décompressez l'archive dans votre répertoire web (ex: `C:\xampp\htdocs` ou `/var/www/html`).
2. Ouvrez un terminal dans le dossier `ges_boutique`.
3. Copiez le fichier `.env.example` vers `.env` (si non présent).
4. Configurez vos accès base de données dans le fichier `.env`.
5. Exécutez `php artisan key:generate`.
6. Exécutez `php artisan migrate --seed` pour créer les tables et charger les données de test.

## Base de données
- Une base de données SQLite pré-remplie est incluse dans `database/database.sqlite`.
- Un export SQL est disponible dans `database/export_base_boutique.sql` si vous préférez utiliser MySQL.

## Utilisation
Lancez le serveur avec `php artisan serve` ou accédez-y via votre hôte virtuel Apache.
Les fonctionnalités incluent :
- Gestion des clients (CRUD)
- Gestion des produits (CRUD)
- Prise de commande avec calcul automatique et mise à jour des stocks
- Génération de facture imprimable en PDF

---
*Projet réalisé pour Monsieur Ali - Génie Informatique L2 2025-2026*
