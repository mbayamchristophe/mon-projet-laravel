<?php

namespace App\Http\Controllers;

use App\Models\Commande;
use App\Models\Client;
use App\Models\Produit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Contrôleur gérant le processus de vente (Commandes et Factures)
 * C'est ici que se trouve la logique complexe de calcul et de gestion des stocks
 */
class CommandeController extends Controller
{
    /**
     * Liste l'historique des commandes passées
     */
    public function index()
    {
        // On utilise eager loading (with) pour charger les clients et éviter les requêtes N+1
        $commandes = Commande::with('client')->orderBy('date_commande', 'desc')->get();
        return view('commandes.index', compact('commandes'));
    }

    /**
     * Formulaire pour passer une nouvelle commande
     */
    public function create()
    {
        $clients = Client::all();
        // On ne propose que les produits qui ont du stock
        $produits = Produit::where('quantite_stock', '>', 0)->get();
        return view('commandes.create', compact('clients', 'produits'));
    }

    /**
     * Enregistre une commande et met à jour les stocks
     * Utilise une TRANSACTION SQL pour garantir l'intégrité des données
     */
    public function store(Request $request)
    {
        // Validation de base
        $request->validate([
            'client_id' => 'required|exists:clients,id',
            'produits' => 'required|array|min:1',
            'produits.*.id' => 'required|exists:produits,id',
            'produits.*.quantite' => 'required|integer|min:1',
        ]);

        // Début de la transaction : si une étape échoue, rien n'est enregistré
        return DB::transaction(function () use ($request) {
            // 1. Création de l'entête de la commande
            $commande = Commande::create([
                'numero_commande' => 'CMD-' . strtoupper(uniqid()), // Génère un numéro unique
                'date_commande' => now(),
                'client_id' => $request->client_id,
                'montant_total' => 0, // Sera calculé juste après
            ]);

            $totalGeneral = 0;

            // 2. Traitement de chaque produit de la commande
            foreach ($request->produits as $item) {
                $produit = Produit::find($item['id']);
                
                // Vérification critique du stock disponible
                if ($produit->quantite_stock < $item['quantite']) {
                    throw new \Exception("Stock insuffisant pour le produit : " . $produit->designation);
                }

                $prixLigne = $produit->prix_unitaire;
                $montantLigne = $prixLigne * $item['quantite'];
                $totalGeneral += $montantLigne;

                // 3. Liaison du produit à la commande (Table Pivot)
                $commande->produits()->attach($produit->id, [
                    'quantite' => $item['quantite'],
                    'prix_unitaire' => $prixLigne
                ]);

                // 4. Décrémentation du stock du produit
                $produit->decrement('quantite_stock', $item['quantite']);
            }

            // 5. Mise à jour du montant total final de la commande
            $commande->update(['montant_total' => $totalGeneral]);

            return redirect()->route('commandes.show', $commande)->with('success', 'Commande validée avec succès !');
        });
    }

    /**
     * Affiche la facture détaillée d'une commande
     */
    public function show(Commande $commande)
    {
        // Charge les relations nécessaires pour la facture
        $commande->load(['client', 'produits']);
        return view('commandes.show', compact('commande'));
    }

    /**
     * Supprime une commande et RESTAURE les stocks
     */
    public function destroy(Commande $commande)
    {
        DB::transaction(function () use ($commande) {
            // Pour chaque produit de la commande, on rend les quantités au stock
            foreach ($commande->produits as $produit) {
                $produit->increment('quantite_stock', $produit->pivot->quantite);
            }
            // Suppression de la commande (les lignes de la table pivot seront supprimées par la cascade si configurée)
            $commande->delete();
        });

        return redirect()->route('commandes.index')->with('success', 'Commande annulée et stock restauré.');
    }
}
