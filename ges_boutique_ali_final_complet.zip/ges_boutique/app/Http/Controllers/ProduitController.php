<?php

namespace App\Http\Controllers;

use App\Models\Produit;
use Illuminate\Http\Request;

/**
 * Contrôleur gérant le catalogue des produits et les stocks
 */
class ProduitController extends Controller
{
    /**
     * Affiche la liste des produits en stock
     */
    public function index()
    {
        $produits = Produit::all();
        return view('produits.index', compact('produits'));
    }

    /**
     * Formulaire d'ajout d'un nouveau produit
     */
    public function create()
    {
        return view('produits.create');
    }

    /**
     * Enregistre le produit et valide la référence unique
     */
    public function store(Request $request)
    {
        $request->validate([
            'reference' => 'required|unique:produits|max:50',
            'designation' => 'required|string|max:255',
            'prix_unitaire' => 'required|numeric|min:0',
            'quantite_stock' => 'required|integer|min:0',
        ]);

        Produit::create($request->all());

        return redirect()->route('produits.index')->with('success', 'Produit ajouté avec succès.');
    }

    /**
     * Affiche les détails d'un produit
     */
    public function show(Produit $produit)
    {
        return view('produits.show', compact('produit'));
    }

    /**
     * Formulaire de modification d'un produit
     */
    public function edit(Produit $produit)
    {
        return view('produits.edit', compact('produit'));
    }

    /**
     * Met à jour les informations du produit et son stock
     */
    public function update(Request $request, Produit $produit)
    {
        $request->validate([
            'reference' => 'required|unique:produits,reference,' . $produit->id,
            'designation' => 'required|string|max:255',
            'prix_unitaire' => 'required|numeric|min:0',
            'quantite_stock' => 'required|integer|min:0',
        ]);

        $produit->update($request->all());

        return redirect()->route('produits.index')->with('success', 'Produit mis à jour avec succès.');
    }

    /**
     * Supprime définitivement un produit du catalogue
     */
    public function destroy(Produit $produit)
    {
        $produit->delete();
        return redirect()->route('produits.index')->with('success', 'Produit supprimé avec succès.');
    }
}
