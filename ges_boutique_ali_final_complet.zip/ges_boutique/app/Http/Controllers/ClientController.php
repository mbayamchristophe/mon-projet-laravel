<?php

namespace App\Http\Controllers;

use App\Models\Client;
use Illuminate\Http\Request;

/**
 * Contrôleur gérant toutes les opérations liées aux clients
 */
class ClientController extends Controller
{
    /**
     * Affiche la liste de tous les clients
     */
    public function index()
    {
        // Récupère tous les clients de la base de données
        $clients = Client::all();
        // Retourne la vue index avec les données des clients
        return view('clients.index', compact('clients'));
    }

    /**
     * Affiche le formulaire de création d'un nouveau client
     */
    public function create()
    {
        return view('clients.create');
    }

    /**
     * Enregistre un nouveau client dans la base de données
     */
    public function store(Request $request)
    {
        // Validation des données saisies par l'utilisateur
        $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'telephone' => 'required|string|max:20',
            'adresse' => 'required|string',
            'email' => 'required|email|unique:clients', // L'email doit être unique dans la table clients
        ]);

        // Création du client avec toutes les données validées
        Client::create($request->all());

        // Redirection vers la liste avec un message de succès
        return redirect()->route('clients.index')->with('success', 'Client ajouté avec succès.');
    }

    /**
     * Affiche les détails d'un client spécifique
     */
    public function show(Client $client)
    {
        return view('clients.show', compact('client'));
    }

    /**
     * Affiche le formulaire de modification pour un client existant
     */
    public function edit(Client $client)
    {
        return view('clients.edit', compact('client'));
    }

    /**
     * Met à jour les informations d'un client dans la base de données
     */
    public function update(Request $request, Client $client)
    {
        // Validation des données (on ignore l'email actuel du client pour la règle unique)
        $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'telephone' => 'required|string|max:20',
            'adresse' => 'required|string',
            'email' => 'required|email|unique:clients,email,' . $client->id,
        ]);

        // Mise à jour des informations
        $client->update($request->all());

        return redirect()->route('clients.index')->with('success', 'Client mis à jour avec succès.');
    }

    /**
     * Supprime un client de la base de données
     */
    public function destroy(Client $client)
    {
        $client->delete();
        return redirect()->route('clients.index')->with('success', 'Client supprimé avec succès.');
    }
}
