<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Modèle représentant une Vente (Commande)
 */
class Commande extends Model
{
    /**
     * Colonnes de la table commandes
     */
    protected $fillable = [
        'numero_commande',
        'date_commande',
        'client_id',
        'montant_total'
    ];

    /**
     * Relation inverse : Une commande appartient à un client unique
     */
    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    /**
     * Relation Many-to-Many avec les Produits
     * Une commande contient une liste de produits avec leur quantité respective
     */
    public function produits()
    {
        return $this->belongsToMany(Produit::class, 'commande_produits')
                    ->withPivot('quantite', 'prix_unitaire')
                    ->withTimestamps();
    }
}
