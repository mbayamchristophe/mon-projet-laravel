<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Modèle représentant un Client dans le système
 */
class Client extends Model
{
    /**
     * Liste des colonnes de la base de données qui peuvent être remplies via Client::create()
     */
    protected $fillable = [
        'nom',
        'prenom',
        'telephone',
        'adresse',
        'email'
    ];

    /**
     * Relation : Un client peut posséder plusieurs commandes (1 vers N)
     */
    public function commandes()
    {
        return $this->hasMany(Commande::class);
    }
}
