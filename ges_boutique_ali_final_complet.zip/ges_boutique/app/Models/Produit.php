<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Modèle représentant un Produit du catalogue
 */
class Produit extends Model
{
    /**
     * Champs de la table produits
     */
    protected $fillable = [
        'reference',
        'designation',
        'prix_unitaire',
        'quantite_stock',
        'description'
    ];

    /**
     * Relation Many-to-Many avec les Commandes
     * Un produit peut être présent dans plusieurs commandes différentes
     */
    public function commandes()
    {
        return $this->belongsToMany(Commande::class, 'commande_produits')
                    ->withPivot('quantite', 'prix_unitaire')
                    ->withTimestamps();
    }
}
