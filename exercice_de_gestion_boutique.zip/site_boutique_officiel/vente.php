<?php
/**
 * OPÉRATION DE VENTE : Style GI2
 */

$con = mysqli_connect('localhost', 'genie', 'genie', 'gestion_boutique');

// Traitement de la vente
if(isset($_POST['vendre'])){
    $id_c = $_POST['id_c'];
    $id_p = $_POST['id_p'];
    $qte = $_POST['qte'];

    // Récupérer prix produit
    $res = mysqli_query($con, "SELECT prix, quantite FROM produit WHERE id=$id_p");
    $p_data = mysqli_fetch_row($res);
    
    if($p_data[1] >= $qte){
        $total = $p_data[0] * $qte;
        
        // Insérer l'opération
        $sql = "INSERT INTO operation (client_id, produit_id, qte_vendue, total) VALUES ($id_c, $id_p, $qte, $total)";
        mysqli_query($con, $sql);
        
        // Déduire du stock
        mysqli_query($con, "UPDATE produit SET quantite = quantite - $qte WHERE id=$id_p");
        
        header('location:boutique.php?msg=Vente enregistrée');
    } else {
        header('location:vente.php?msg=Stock insuffisant');
    }
    exit();
}

// Listes pour les sélections
$cls = mysqli_fetch_all(mysqli_query($con, "SELECT id, nom, prenom FROM client"));
$prods = mysqli_fetch_all(mysqli_query($con, "SELECT id, designation, quantite FROM produit"));
?>

<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Nouvelle Vente</title></head>
<body>
    <h2>Passer une Commande</h2>
    <?php if(isset($_GET['msg'])) echo "<p style='color:red;'>".$_GET['msg']."</p>"; ?>
    <form method="POST" action="vente.php">
        <p>Client : 
            <select name="id_c">
                <?php foreach($cls as $c) echo "<option value='$c[0]'>$c[1] $c[2]</option>"; ?>
            </select>
        </p>
        <p>Produit : 
            <select name="id_p">
                <?php foreach($prods as $p) echo "<option value='$p[0]'>$p[1] (Stock: $p[2])</option>"; ?>
            </select>
        </p>
        <p>Quantité : <input type="number" name="qte" value="1" min="1"></p>
        <input type="submit" name="vendre" value="Valider la vente">
        <a href="boutique.php">Retour</a>
    </form>
</body>
</html>
