<?php
/**
 * PAGE PRINCIPALE : BOUTIQUE DE VENTE DE M. ALI
 * Style : Procédural GI2
 */

// Connexion à la base de données
$con = mysqli_connect('localhost', 'genie', 'genie', 'gestion_boutique');

if (!$con) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

// Récupération des données
$sql = "SELECT * FROM client;";
$sql1 = "SELECT * FROM produit;";
$exe = mysqli_query($con, $sql);
$exe1 = mysqli_query($con, $sql1);

$clients = mysqli_fetch_all($exe);
$produits = mysqli_fetch_all($exe1);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Boutique de vente de M. ALI</title>
    <style>
        body { font-family: sans-serif; margin: 30px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table, th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        .msg { background: #e2e2e2; padding: 10px; margin-bottom: 20px; }
    </style>
</head>
<body>

<h1>Boutique de vente de M. ALI</h1>

<?php if(isset($_GET['msg'])) echo "<div class='msg'>".$_GET['msg']."</div>"; ?>

<!-- SECTION CLIENTS -->
<h2>Clients</h2>
<form method="POST" action="boutique.php">
    <input type="text" name="nom" placeholder="Entrer le nom du client">
    <input type="submit" name="recher" value="Rechercher">
    <a href="boutique.php">Annuler</a>
</form>

<table>
    <tr>
        <th>ID</th><th>NOM</th><th>PRENOM</th><th>TELEPHONE</th><th>VILLE</th><th>QUARTIER</th><th colspan="2">Actions</th>
    </tr>

<?php
if(!(isset($_POST['recher']))){
    if($clients != []){
        foreach($clients as $client){
            echo "
            <tr>
                <td>".$client[0]."</td>
                <td>".$client[1]."</td>
                <td>".$client[2]."</td>
                <td>".$client[3]."</td>
                <td>".$client[4]."</td>
                <td>".$client[5]."</td>
                <td><a style='color:green; text-decoration:none;' href='modif_client.php?val=$client[0]'>MODIFIER</a></td>
                <td><a style='color:red; text-decoration:none;' href='supprim_client.php?val=$client[0]'>SUPPRIMER</a></td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='8'>Pas de client enregistrer</td></tr>";
    }
}

if(isset($_POST['recher'])){
    $rch = $_POST['nom'];
    $sqle = 'SELECT * FROM client where nom="'.$rch.'";';
    $exxe = mysqli_query($con, $sqle);
    $client1 = mysqli_fetch_all($exxe);
    
    if($client1 != []){
        foreach($client1 as $clientt){
            echo "
            <tr>
                <td>".$clientt[0]."</td>
                <td>".$clientt[1]."</td>
                <td>".$clientt[2]."</td>
                <td>".$clientt[3]."</td>
                <td>".$clientt[4]."</td>
                <td>".$clientt[5]."</td>
                <td><a style='color:green; text-decoration:none;' href='modif_client.php?val=$clientt[0]'>MODIFIER</a></td>
                <td><a style='color:red; text-decoration:none;' href='supprim_client.php?val=$clientt[0]'>SUPPRIMER</a></td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='8'>Aucun résultat pour la recherche</td></tr>";
    }
}
?>
</table>
<hr><br>
<a style='color:green; text-decoration:none;' href='aclient.php'>Ajouter un client</a>

<!-- SECTION PRODUITS -->
<br><br>
<h2>Produits</h2>
<table>
    <tr>
        <th>ID</th><th>Désignation</th><th>Prix</th><th>Stock</th><th>Action</th>
    </tr>
<?php
foreach($produits as $p){
    echo "
    <tr>
        <td>".$p[0]."</td>
        <td>".$p[1]."</td>
        <td>".$p[2]." F</td>
        <td>".$p[3]."</td>
        <td><a style='color:green; text-decoration:none;' href='aproduit.php?edit=$p[0]'>MODIFIER</a></td>
    </tr>";
}
?>
</table>
<br>
<a style='color:green; text-decoration:none;' href='aproduit.php'>Ajouter un produit</a>

<!-- SECTION OPÉRATIONS -->
<br><br>
<h2>Opérations</h2>
<form method="POST" action="facture.php">
    <input type="text" name="id_op" placeholder="Numéro d'opération">
    <input type="submit" name="voir_facture" value="Générer Facture">
</form>
<br>
<a style='color:blue; text-decoration:none;' href='vente.php'>Passer une Commande</a>

</body>
</html>
