<?php
/**
 * FACTURE : Style GI2
 */
$con = mysqli_connect('localhost', 'genie', 'genie', 'gestion_boutique');

$id_op = 0;
if(isset($_POST['voir_facture'])) $id_op = $_POST['id_op'];
if(isset($_GET['id'])) $id_op = $_GET['id'];

$sql = "SELECT o.*, c.nom, c.prenom, p.designation, p.prix 
        FROM operation o 
        JOIN client c ON o.client_id = c.id 
        JOIN produit p ON o.produit_id = p.id 
        WHERE o.id = $id_op";

$res = mysqli_query($con, $sql);
$data = mysqli_fetch_row($res);

if(!$data) die("Opération introuvable.");
?>

<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Facture</title></head>
<body>
    <div style="border:1px solid #000; padding:20px; width:500px; margin:auto;">
        <h1 style="text-align:center;">FACTURE BOUTIQUE ALI</h1>
        <hr>
        <p><strong>Client :</strong> <?php echo $data[5]." ".$data[6]; ?></p>
        <p><strong>Date :</strong> <?php echo $data[4]; ?></p>
        <hr>
        <table border="1" width="100%">
            <tr><th>Désignation</th><th>Quantité</th><th>Total</th></tr>
            <tr>
                <td><?php echo $data[7]; ?></td>
                <td><?php echo $data[3]; ?></td>
                <td><?php echo $data[8]; ?> F</td>
            </tr>
        </table>
        <h3 style="text-align:right;">TOTAL : <?php echo $data[8]; ?> F CFA</h3>
        <br>
        <button onclick="window.print()">Imprimer</button>
        <a href="boutique.php">Retour</a>
    </div>
</body>
</html>
