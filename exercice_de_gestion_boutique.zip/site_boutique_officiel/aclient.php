<?php
/**
 * AJOUT CLIENT : Style GI2
 */

if(isset($_POST['enr'])){
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $tel = $_POST['tel'];
    $ville = $_POST['ville'];
    $quartier = $_POST['quartier'];

    $con = mysqli_connect('localhost', 'genie', 'genie', 'gestion_boutique');
    
    $sql = "INSERT INTO client (nom, prenom, tel, ville, quartier) 
            VALUES ('$nom', '$prenom', '$tel', '$ville', '$quartier')";

    $exe = mysqli_query($con, $sql);
    
    if($exe){
        header('location:boutique.php?msg=le client '.$nom.' est ajouter avec succee');
    } else {
        header('location:boutique.php?msg=le client '.$nom.' n\'est pas ajouer!');
    }
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ajouter un client</title>
</head>
<body>
    <h2>Nouveau Client</h2>
    <form method="POST" action="aclient.php">
        <p>Nom : <input type="text" name="nom" required></p>
        <p>Prénom : <input type="text" name="prenom" required></p>
        <p>Tél : <input type="text" name="tel" required></p>
        <p>Ville : <input type="text" name="ville" required></p>
        <p>Quartier : <input type="text" name="quartier" required></p>
        <input type="submit" name="enr" value="Enregistrer">
        <a href="boutique.php">Retour</a>
    </form>
</body>
</html>
