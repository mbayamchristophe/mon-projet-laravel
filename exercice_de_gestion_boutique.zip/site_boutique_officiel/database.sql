-- Création de la base de données selon le code de l'enseignant
CREATE DATABASE IF NOT EXISTS `gestion_boutique`;
USE `gestion_boutique`;

-- Table client
CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `quartier` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table produit
CREATE TABLE IF NOT EXISTS `produit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) NOT NULL,
  `prix` decimal(10,2) NOT NULL,
  `quantite` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table operation (commandes)
CREATE TABLE IF NOT EXISTS `operation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `produit_id` int(11) NOT NULL,
  `qte_vendue` int(11) NOT NULL,
  `date_op` datetime DEFAULT CURRENT_TIMESTAMP,
  `total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`client_id`) REFERENCES `client`(`id`),
  FOREIGN KEY (`produit_id`) REFERENCES `produit`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insertion de données initiales
INSERT INTO `client` (`nom`, `prenom`, `tel`, `ville`, `quartier`) VALUES
('ZARA', 'LOUISE', '35672828', 'Doba', 'Carré 5');

INSERT INTO `produit` (`designation`, `prix`, `quantite`) VALUES
('Ordinateur HP', 250000, 10);
